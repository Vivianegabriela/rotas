const mysql = require("mysql");
const database = "dados";

// instanciar objeto de acesso ao banco de dados
var conexao = mysql.createConnection({
    user:"root",
    password:"",
    host: "localhost",
    port:3306
})

conexao.connect((err) => {
    if(err){
        console.log("Erro ao conectar ao Banco de Dados Mysql");
        return
    }

    console.log("\n Conexão estabelecida com sucesso!!")
}) 

module.exports = conexao;