const conexao = require("../../config/conexao.js")

module.exports = {
    versaoMysql,
}

function versaoMysql(callback){
    console.log("Dentro da {MODEL}")
    
    const m_sql = "select version()";
    
    conexao.query(m_sql, callback);

    console.log("Retornando da consulta!");

}
