module.exports = {
    menuClassificadosControllers
}

function menuClassificadosControllers(req, res) {
    // res.send("Rota de Classificados Encontrada!");
    
    
    res.render('classificados/frm_classificadosMenu.ejs', {title: 'Classificados',
                                                 titulo:'Menu Classificados'
    });
    
}





