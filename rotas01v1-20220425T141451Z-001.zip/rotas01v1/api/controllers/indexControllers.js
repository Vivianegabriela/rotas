const indexController = require('../models/indexModels');

module.exports = {
    indexControllers,
    getVrMysql

}


function indexControllers(req, res) {
    res.render('index.ejs', {title: 'Projeto NodeJs-Rotas',
                             titulo:'Menu Principal',
                             versao: 'Versão Mysql',
                             data: 'Obter Data',
                             hora: 'Obter Hora'
 
    });
}

function getVrMysql(req, res, next){
    console.log("Dentro do Controller\n {GET Versão Mysql}");
    
    indexController.versaoMysql(function(err, resultado){
        if(err){
            console.log("Erro", err)
            throw err;
        }else{
            console.log("Versão Obtida: ", resultado)
            res.send(resultado)
        }
        
    })
}