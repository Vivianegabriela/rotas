module.exports = {
    menuLazerControllers
}

function menuLazerControllers(req, res) {
    // res.send("Rota de Lazer Encontrada!");
    
    
    res.render('lazer/frm_lazerMenu.ejs', {title: 'Lazer',
                                                 titulo:'Menu Lazer'
    });
    
}





