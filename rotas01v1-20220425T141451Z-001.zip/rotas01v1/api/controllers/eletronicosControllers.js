module.exports = {
    menuEletronicosControllers
}

function menuEletronicosControllers(req, res) {
    res.send("Rota de Eletronicos Encontrada!");
    
    /*
    res.render('eletronicos/frm_eletronicosMenu.ejs', {title: 'Eletronicos',
                                                 titulo:'Menu Eletronicos'
    });
    */
}





