module.exports = {
    menuReceitasControllers
}

function menuReceitasControllers(req, res) {
    // res.send("Rota de Receitas Encontrada!");
    
    
    res.render('receitas/frm_receitasMenu.ejs', {title: 'Receitas',
                                                 titulo:'Menu Receitas'
    });
    
}





