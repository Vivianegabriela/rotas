const controllerClassificados = require('../controllers/classificadosControllers.js');

app.get('/classificados/classificadosMenu', controllerClassificados.menuClassificadosControllers);
