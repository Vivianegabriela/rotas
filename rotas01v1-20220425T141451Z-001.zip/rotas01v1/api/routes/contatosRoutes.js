const controllerContatos = require('../controllers/contatosControllers.js');

app.get('/contatos/contatosMenu', controllerContatos.menuContatosControllers);
