// function vrMysql(){
//     document.getElementById("versaoMysql").innerHTML = "Inserir Versão";
// }

function fdate(){
    dayName = new Array("domingo","segunda","terça","quarta","quinta","sexta","sabado");
    monName = new Array("Janeiro","Fevereiro","Março","Abril","Mario","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro",);
    now = new Date;

    const hoje = "Hoje é " + dayName[now.getDay()] + ", " + now.getDate() + " de " +
    monName[now.getMonth()] + " de " + now.getFullYear() + "."
    
    document.getElementById("data").innerHTML = "Data Atual: " + hoje
}

function fhora(){
    today = new Date();

    h = today.getHours();
    m = today.getMinutes();
    s = today.getSeconds();

    console.log("Hora Certa: " + h + ":" + m + ":" + s)
    horaFormat = h + ":" + m + ":" + s

    document.getElementById("hora").innerHTML = "Hora Certa: " + horaFormat
}
